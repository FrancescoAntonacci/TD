# README

* misura01.txt: tensione costante;
* misura02.txt: tensione sinsoide;
* misura03.txt: Ch1Ch2 cortocircuitati;
* misura04.txt: Ch1 scollegato;
* misura05.txt: partitore rng5;
* misura06.txt: partitore rng4;
* misura07.txt: partitore rng3.1;